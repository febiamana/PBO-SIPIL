package com.pbo.inventaris.model;

import java.util.Date;

public class Peminjaman {
    private int id;
    private String namaPeminjam;
    private int barangId;
    private String namaBarang; // Helper field for display
    private Date tanggalPinjam;
    private Date tanggalKembali;
    private String status;

    public Peminjaman() {}

    public Peminjaman(int id, String namaPeminjam, int barangId, Date tanggalPinjam, Date tanggalKembali, String status) {
        this.id = id;
        this.namaPeminjam = namaPeminjam;
        this.barangId = barangId;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalKembali = tanggalKembali;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNamaPeminjam() { return namaPeminjam; }
    public void setNamaPeminjam(String namaPeminjam) { this.namaPeminjam = namaPeminjam; }

    public int getBarangId() { return barangId; }
    public void setBarangId(int barangId) { this.barangId = barangId; }

    public String getNamaBarang() { return namaBarang; }
    public void setNamaBarang(String namaBarang) { this.namaBarang = namaBarang; }

    public Date getTanggalPinjam() { return tanggalPinjam; }
    public void setTanggalPinjam(Date tanggalPinjam) { this.tanggalPinjam = tanggalPinjam; }

    public Date getTanggalKembali() { return tanggalKembali; }
    public void setTanggalKembali(Date tanggalKembali) { this.tanggalKembali = tanggalKembali; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
