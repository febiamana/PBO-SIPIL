package com.pbo.inventaris.dao;

import com.pbo.inventaris.DatabaseHelper;
import com.pbo.inventaris.model.Peminjaman;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PeminjamanDAO {

    public List<Peminjaman> getAllPeminjaman() {
        List<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT p.*, b.nama as nama_barang FROM peminjaman p JOIN barang b ON p.barang_id = b.id ORDER BY p.tanggal_pinjam DESC";
        
        try (Connection conn = DatabaseHelper.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Peminjaman p = new Peminjaman();
                p.setId(rs.getInt("id"));
                p.setNamaPeminjam(rs.getString("nama_peminjam"));
                p.setBarangId(rs.getInt("barang_id"));
                p.setNamaBarang(rs.getString("nama_barang"));
                p.setTanggalPinjam(rs.getTimestamp("tanggal_pinjam"));
                p.setTanggalKembali(rs.getTimestamp("tanggal_kembali"));
                p.setStatus(rs.getString("status"));
                list.add(p);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal memuat data peminjaman: " + e.getMessage());
        }
        return list;
    }

    public boolean addPeminjaman(Peminjaman peminjaman) {
        String checkStockSql = "SELECT stok FROM barang WHERE id = ?";
        String insertSql = "INSERT INTO peminjaman (nama_peminjam, barang_id, status) VALUES (?, ?, 'DIPINJAM')";
        String updateStockSql = "UPDATE barang SET stok = stok - 1 WHERE id = ?";
        
        Connection conn = null;
        try {
            conn = DatabaseHelper.getConnection();
            conn.setAutoCommit(false); // Start transaction

            // Check stock
            try (PreparedStatement pstmtCheck = conn.prepareStatement(checkStockSql)) {
                pstmtCheck.setInt(1, peminjaman.getBarangId());
                ResultSet rs = pstmtCheck.executeQuery();
                if (rs.next()) {
                    int currentStock = rs.getInt("stok");
                    if (currentStock <= 0) {
                        return false; // Stock empty
                    }
                } else {
                    return false; // Item not found
                }
            }

            // Insert peminjaman
            try (PreparedStatement pstmtInsert = conn.prepareStatement(insertSql)) {
                pstmtInsert.setString(1, peminjaman.getNamaPeminjam());
                pstmtInsert.setInt(2, peminjaman.getBarangId());
                pstmtInsert.executeUpdate();
            }

            // Update stock
            try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateStockSql)) {
                pstmtUpdate.setInt(1, peminjaman.getBarangId());
                pstmtUpdate.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            JOptionPane.showMessageDialog(null, "Gagal menambah peminjaman: " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }

    public void kembalikanBarang(int peminjamanId) {
        String selectSql = "SELECT barang_id, status FROM peminjaman WHERE id = ?";
        String updatePeminjamanSql = "UPDATE peminjaman SET status = 'DIKEMBALIKAN', tanggal_kembali = NOW() WHERE id = ?";
        String updateStockSql = "UPDATE barang SET stok = stok + 1 WHERE id = ?";

        Connection conn = null;
        try {
            conn = DatabaseHelper.getConnection();
            conn.setAutoCommit(false);

            int barangId = -1;
            String currentStatus = "";

            try (PreparedStatement pstmt = conn.prepareStatement(selectSql)) {
                pstmt.setInt(1, peminjamanId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    barangId = rs.getInt("barang_id");
                    currentStatus = rs.getString("status");
                }
            }

            if (barangId != -1 && "DIPINJAM".equals(currentStatus)) {
                try (PreparedStatement pstmt = conn.prepareStatement(updatePeminjamanSql)) {
                    pstmt.setInt(1, peminjamanId);
                    pstmt.executeUpdate();
                }

                try (PreparedStatement pstmt = conn.prepareStatement(updateStockSql)) {
                    pstmt.setInt(1, barangId);
                    pstmt.executeUpdate();
                }
                conn.commit();
            }

        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            JOptionPane.showMessageDialog(null, "Gagal mengembalikan barang: " + e.getMessage());
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }
}
