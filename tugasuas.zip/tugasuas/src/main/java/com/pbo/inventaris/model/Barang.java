package com.pbo.inventaris.model;

public class Barang {
    private int id;
    private String nama;
    private String kategori;
    private int stok;

    public Barang() {}

    public Barang(int id, String nama, String kategori, int stok) {
        this.id = id;
        this.nama = nama;
        this.kategori = kategori;
        this.stok = stok;
    }

    public Barang(String nama, String kategori, int stok) {
        this.nama = nama;
        this.kategori = kategori;
        this.stok = stok;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public int getStok() { return stok; }
    public void setStok(int stok) { this.stok = stok; }

    @Override
    public String toString() {
        return nama + " (" + stok + ")";
    }
}
