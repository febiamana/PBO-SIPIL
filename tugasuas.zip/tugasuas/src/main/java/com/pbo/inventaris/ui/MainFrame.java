package com.pbo.inventaris.ui;

import com.pbo.inventaris.dao.BarangDAO;
import com.pbo.inventaris.dao.PeminjamanDAO;
import com.pbo.inventaris.model.Barang;
import com.pbo.inventaris.model.Peminjaman;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;

public class MainFrame extends JFrame {
    private BarangDAO barangDAO;
    private PeminjamanDAO peminjamanDAO;

    private JTable tableBarang;
    private DefaultTableModel modelBarang;
    private JTable tablePeminjaman;
    private DefaultTableModel modelPeminjaman;

    // Form fields for Barang
    private JTextField txtNamaBarang;
    private JTextField txtKategoriBarang;
    private JTextField txtStokBarang;

    // Form fields for Peminjaman
    private JTextField txtNamaPeminjam;
    private JComboBox<Barang> comboBarang;

    public MainFrame() {
        barangDAO = new BarangDAO();
        peminjamanDAO = new PeminjamanDAO();

        setTitle("Sistem Inventaris Laboratorium");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try (Connection c = com.pbo.inventaris.DatabaseHelper.getConnection()) {
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Koneksi database gagal: " + ex.getMessage());
        }

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Manajemen Barang", createBarangPanel());
        tabbedPane.addTab("Peminjaman & Pengembalian", createPeminjamanPanel());

        add(tabbedPane);
    }

    private JPanel createBarangPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Table
        String[] columns = {"ID", "Nama", "Kategori", "Stok"};
        modelBarang = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tableBarang = new JTable(modelBarang);
        tableBarang.setRowHeight(25);
        tableBarang.getTableHeader().setReorderingAllowed(false);
        loadDataBarang();
        panel.add(new JScrollPane(tableBarang), BorderLayout.CENTER);

        // Form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Input Data Barang"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Row 1
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Nama Barang:"), gbc);
        
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        txtNamaBarang = new JTextField();
        formPanel.add(txtNamaBarang, gbc);
        
        // Row 2
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Kategori:"), gbc);
        
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        txtKategoriBarang = new JTextField();
        formPanel.add(txtKategoriBarang, gbc);

        // Row 3
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Stok:"), gbc);
        
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        txtStokBarang = new JTextField();
        formPanel.add(txtStokBarang, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnAdd = new JButton("Tambah");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Hapus");
        JButton btnRefresh = new JButton("Refresh");
        
        // Styling buttons
        btnAdd.setBackground(new Color(40, 167, 69)); btnAdd.setForeground(Color.WHITE);
        btnUpdate.setBackground(new Color(255, 193, 7)); btnUpdate.setForeground(Color.BLACK);
        btnDelete.setBackground(new Color(220, 53, 69)); btnDelete.setForeground(Color.WHITE);
        btnRefresh.setBackground(new Color(23, 162, 184)); btnRefresh.setForeground(Color.WHITE);

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(formPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        // Actions
        btnAdd.addActionListener(e -> addBarang());
        btnUpdate.addActionListener(e -> updateBarang());
        btnDelete.addActionListener(e -> deleteBarang());
        btnRefresh.addActionListener(e -> loadDataBarang());

        // Selection Listener
        tableBarang.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = tableBarang.getSelectedRow();
            if (selectedRow != -1) {
                txtNamaBarang.setText(modelBarang.getValueAt(selectedRow, 1).toString());
                txtKategoriBarang.setText(modelBarang.getValueAt(selectedRow, 2).toString());
                txtStokBarang.setText(modelBarang.getValueAt(selectedRow, 3).toString());
            }
        });

        return panel;
    }

    private JPanel createPeminjamanPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Table
        String[] columns = {"ID", "Peminjam", "Barang", "Tgl Pinjam", "Tgl Kembali", "Status"};
        modelPeminjaman = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablePeminjaman = new JTable(modelPeminjaman);
        tablePeminjaman.setRowHeight(25);
        tablePeminjaman.getTableHeader().setReorderingAllowed(false);
        loadDataPeminjaman();
        panel.add(new JScrollPane(tablePeminjaman), BorderLayout.CENTER);

        // Form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Transaksi Peminjaman"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Row 1
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Nama Peminjam:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        txtNamaPeminjam = new JTextField();
        formPanel.add(txtNamaPeminjam, gbc);

        // Row 2
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Pilih Barang:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        comboBarang = new JComboBox<>();
        loadComboBarang();
        formPanel.add(comboBarang, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnPinjam = new JButton("Pinjam Barang");
        JButton btnKembali = new JButton("Kembalikan Barang");
        JButton btnRefresh = new JButton("Refresh");

        // Styling buttons
        btnPinjam.setBackground(new Color(0, 123, 255)); btnPinjam.setForeground(Color.WHITE);
        btnKembali.setBackground(new Color(40, 167, 69)); btnKembali.setForeground(Color.WHITE);
        btnRefresh.setBackground(new Color(23, 162, 184)); btnRefresh.setForeground(Color.WHITE);

        buttonPanel.add(btnPinjam);
        buttonPanel.add(btnKembali);
        buttonPanel.add(btnRefresh);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(formPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        // Actions
        btnPinjam.addActionListener(e -> pinjamBarang());
        btnKembali.addActionListener(e -> kembalikanBarang());
        btnRefresh.addActionListener(e -> {
            loadDataPeminjaman();
            loadComboBarang();
            loadDataBarang(); // Sync barang table too
        });

        return panel;
    }

    // --- Logic Methods for Barang ---

    private void loadDataBarang() {
        modelBarang.setRowCount(0);
        List<Barang> list = barangDAO.getAllBarang();
        for (Barang b : list) {
            modelBarang.addRow(new Object[]{b.getId(), b.getNama(), b.getKategori(), b.getStok()});
        }
        tableBarang.revalidate();
        tableBarang.repaint();
    }

    private void addBarang() {
        try {
            String nama = txtNamaBarang.getText();
            String kategori = txtKategoriBarang.getText();
            int stok = Integer.parseInt(txtStokBarang.getText());

            Barang barang = new Barang(nama, kategori, stok);
            barangDAO.addBarang(barang);
            loadDataBarang();
            clearFormBarang();
            JOptionPane.showMessageDialog(this, "Barang berhasil ditambahkan!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok harus berupa angka!");
        }
    }

    private void updateBarang() {
        int selectedRow = tableBarang.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Pilih barang yang akan diedit!");
            return;
        }

        try {
            int id = (int) modelBarang.getValueAt(selectedRow, 0);
            String nama = txtNamaBarang.getText();
            String kategori = txtKategoriBarang.getText();
            int stok = Integer.parseInt(txtStokBarang.getText());

            Barang barang = new Barang(id, nama, kategori, stok);
            barangDAO.updateBarang(barang);
            loadDataBarang();
            clearFormBarang();
            JOptionPane.showMessageDialog(this, "Barang berhasil diupdate!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok harus berupa angka!");
        }
    }

    private void deleteBarang() {
        int selectedRow = tableBarang.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Pilih barang yang akan dihapus!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            int id = (int) modelBarang.getValueAt(selectedRow, 0);
            barangDAO.deleteBarang(id);
            loadDataBarang();
            clearFormBarang();
        }
    }

    private void clearFormBarang() {
        txtNamaBarang.setText("");
        txtKategoriBarang.setText("");
        txtStokBarang.setText("");
    }

    // --- Logic Methods for Peminjaman ---

    private void loadDataPeminjaman() {
        modelPeminjaman.setRowCount(0);
        List<Peminjaman> list = peminjamanDAO.getAllPeminjaman();
        for (Peminjaman p : list) {
            modelPeminjaman.addRow(new Object[]{
                p.getId(),
                p.getNamaPeminjam(),
                p.getNamaBarang(),
                p.getTanggalPinjam(),
                p.getTanggalKembali() != null ? p.getTanggalKembali() : "-",
                p.getStatus()
            });
        }
        tablePeminjaman.revalidate();
        tablePeminjaman.repaint();
    }

    private void loadComboBarang() {
        comboBarang.removeAllItems();
        List<Barang> list = barangDAO.getAllBarang();
        for (Barang b : list) {
            comboBarang.addItem(b);
        }
    }

    private void pinjamBarang() {
        String namaPeminjam = txtNamaPeminjam.getText();
        Barang selectedBarang = (Barang) comboBarang.getSelectedItem();

        if (namaPeminjam.isEmpty() || selectedBarang == null) {
            JOptionPane.showMessageDialog(this, "Isi nama peminjam dan pilih barang!");
            return;
        }

        if (selectedBarang.getStok() <= 0) {
            JOptionPane.showMessageDialog(this, "Stok barang habis!");
            return;
        }

        Peminjaman p = new Peminjaman();
        p.setNamaPeminjam(namaPeminjam);
        p.setBarangId(selectedBarang.getId());

        boolean success = peminjamanDAO.addPeminjaman(p);
        if (success) {
            loadDataPeminjaman();
            loadDataBarang(); // Update stock in barang tab
            loadComboBarang(); // Update stock in combo (if toString uses stock)
            txtNamaPeminjam.setText("");
            JOptionPane.showMessageDialog(this, "Peminjaman berhasil!");
        } else {
            JOptionPane.showMessageDialog(this, "Gagal meminjam barang!");
        }
    }

    private void kembalikanBarang() {
        int selectedRow = tablePeminjaman.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Pilih transaksi yang akan dikembalikan!");
            return;
        }

        String status = (String) modelPeminjaman.getValueAt(selectedRow, 5);
        if ("DIKEMBALIKAN".equals(status)) {
            JOptionPane.showMessageDialog(this, "Barang sudah dikembalikan!");
            return;
        }

        int id = (int) modelPeminjaman.getValueAt(selectedRow, 0);
        peminjamanDAO.kembalikanBarang(id);
        loadDataPeminjaman();
        loadDataBarang(); // Update stock in barang tab
        loadComboBarang();
        JOptionPane.showMessageDialog(this, "Barang berhasil dikembalikan!");
    }

    // Main entry point is now LoginFrame
    // public static void main(String[] args) { ... }
}
