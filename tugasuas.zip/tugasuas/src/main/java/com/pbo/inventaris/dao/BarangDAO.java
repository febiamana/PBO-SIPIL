package com.pbo.inventaris.dao;

import com.pbo.inventaris.DatabaseHelper;
import com.pbo.inventaris.model.Barang;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class BarangDAO {

    public List<Barang> getAllBarang() {
        List<Barang> listBarang = new ArrayList<>();
        String sql = "SELECT * FROM barang";
        
        try (Connection conn = DatabaseHelper.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Barang barang = new Barang(
                    rs.getInt("id"),
                    rs.getString("nama"),
                    rs.getString("kategori"),
                    rs.getInt("stok")
                );
                listBarang.add(barang);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal memuat data barang: " + e.getMessage());
        }
        return listBarang;
    }

    public void addBarang(Barang barang) {
        String sql = "INSERT INTO barang (nama, kategori, stok) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, barang.getNama());
            pstmt.setString(2, barang.getKategori());
            pstmt.setInt(3, barang.getStok());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal menambah barang: " + e.getMessage());
        }
    }

    public void updateBarang(Barang barang) {
        String sql = "UPDATE barang SET nama = ?, kategori = ?, stok = ? WHERE id = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, barang.getNama());
            pstmt.setString(2, barang.getKategori());
            pstmt.setInt(3, barang.getStok());
            pstmt.setInt(4, barang.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal mengubah barang: " + e.getMessage());
        }
    }

    public void deleteBarang(int id) {
        String sql = "DELETE FROM barang WHERE id = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal menghapus barang: " + e.getMessage());
        }
    }
    
    public Barang getBarangById(int id) {
        String sql = "SELECT * FROM barang WHERE id = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Barang(
                        rs.getInt("id"),
                        rs.getString("nama"),
                        rs.getString("kategori"),
                        rs.getInt("stok")
                    );
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal mengambil barang: " + e.getMessage());
        }
        return null;
    }
}
