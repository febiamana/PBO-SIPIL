package com.pbo.inventaris;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseHelper {
    private static final String URL = "jdbc:mariadb://localhost:3306/inventaris_lab";
    private static final String USER = "root";
    private static final String PASSWORD = "oke"; // Sesuaikan dengan password database Anda

    public static Connection getConnection() throws SQLException {
        try {
            // Load driver explicitly just in case (optional for modern JDBC)
            Class.forName("org.mariadb.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MariaDB JDBC Driver not found", e);
        }
    }
}
