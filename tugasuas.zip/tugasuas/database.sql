-- Database Schema
CREATE DATABASE IF NOT EXISTS inventaris_lab;
USE inventaris_lab;

-- Table Barang
CREATE TABLE IF NOT EXISTS barang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    kategori VARCHAR(50),
    stok INT DEFAULT 0
);

-- Table Peminjaman
CREATE TABLE IF NOT EXISTS peminjaman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_peminjam VARCHAR(100) NOT NULL,
    barang_id INT,
    tanggal_pinjam TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tanggal_kembali TIMESTAMP NULL,
    status VARCHAR(20) DEFAULT 'DIPINJAM',
    FOREIGN KEY (barang_id) REFERENCES barang(id)
);

-- Table Users (New for Login)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- In real app, use hashed password
    nama_lengkap VARCHAR(100),
    role VARCHAR(20) DEFAULT 'admin'
);

-- Seed Data
INSERT INTO users (username, password, nama_lengkap) VALUES
('admin', 'admin123', 'Administrator'),

INSERT INTO barang (nama, kategori, stok) VALUES
('Mikroskop', 'Alat Optik', 10),
('Multimeter', 'Elektronik', 8),
('Oscilloscope', 'Elektronik', 3),
('Bunsen Burner', 'Kimia', 12),
('Beaker Glass 500ml', 'Kimia', 20),
('Laptop Lab', 'Komputer', 6),
('Proyektor', 'Audio Visual', 4),
('Obeng Set', 'Mekanik', 15);
